<?php 
include "../funciones.php";
include "funciones_com.php";
cabecera("Buscar Asignaciones","styles.css");
session_start();

// Establecer las variables de sesión con los valores del formulario actual
$_SESSION['empresa'] = recoger("empresa");
$_SESSION['alumno'] = recoger("alumno");
$_SESSION['contratacion'] = recoger("contratacion");

$conexion = conexion("172.20.131.102","ftc");
$query = "SELECT 
    a.horario,
    a.observaciones,
    a.trabajo,
    a.contrato,
    h.curso,
    CONCAT(al.nombre, ' ', al.apellidos) AS 'nombre_alumno',
    r.nombre AS 'nombre_responsable',
    e.razon_social 
FROM 
    asignaciones a, 
    alumnos al, 
    empresas e, 
    responsables r, 
    historico h 
WHERE 
    a.curso = h.idhistorico 
    AND a.alumno = al.idalumnos 
    AND a.responsable = r.idresponsable 
    AND a.empresa = e.idempresas;";

if ($_SESSION['tipo_usuario'] == "admin") {
    nav_admin();
} else {
    nav_user();
}

if (isset($_POST['mostrar'])) {
    $_SESSION['empresa'] = "";
    $_SESSION['alumno'] = "";
    $_SESSION['contratacion'] = "";
}
if (isset($_POST['buscar'])) {
    $empresa = $_POST['empresa'];
    $alumno = $_POST['alumno'];
    $contratacion = $_POST['contratacion'];
    $query = "SELECT 
    a.horario,
    a.observaciones,
    a.trabajo,
    a.contrato,
    h.curso,
    CONCAT(al.nombre, ' ', al.apellidos) AS 'nombre_alumno',
    r.nombre AS 'nombre_responsable',
    e.razon_social 
FROM 
    asignaciones a, 
    alumnos al, 
    empresas e, 
    responsables r, 
    historico h 
WHERE 
    a.curso = h.idhistorico 
    AND a.alumno = al.idalumnos 
    AND a.responsable = r.idresponsable 
    AND a.empresa = e.idempresas
    AND razon_social LIKE '%$empresa%'
    AND CONCAT(al.nombre, ' ', al.apellidos) LIKE '%$alumno%'";
    if ($contratacion != "") {
        $query = $query." AND contrato = '$contratacion'";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Alumnado</title>
    <!-- Tu enlace a los archivos CSS -->
</head>
<body>
    <div class="container">
        <h2>Lista de Asignaciones</h2>
        <br>
        <form action="alumnos_asig.php" method="post">
            <table border="0">
                <tr>
                    <td><input type="text" name="empresa" id="empresa" placeholder="Nombre de la empresa" value="<?php echo $_SESSION['empresa']; ?>"></td>
                    <td><input type="text" name="alumno" id="alumno" placeholder="Nombre del alumno" value="<?php echo $_SESSION['alumno']; ?>"></td>
                    <td><label for="contratacion">Contratación:</label>
                        <select name="contratacion" id="contratacion">
                            <option value="" selected>Ignorar</option>
                            <option value="si" <?php s_poner_selected("contratacion","si"); ?>>Si</option>
                            <option value="no" <?php s_poner_selected("contratacion","no"); ?>>No</option>
                        </select>
                    </td>
                    <td><button type="submit" name="buscar" id="buscar">Buscar Asignaciones</button></td>
                    <td><button type="submit" name="mostrar" id="Mostrar todos">Mostrar Todas</button></td>
                </tr>
            </table>
        </form>
        <div class="list-container">
            <table>
                <tr>
                    <th>Empresa</th>
                    <th>Alumno</th>
                    <th>Horario</th>
                    <th>Curso</th>
                    <th>Trabajo</th>
                    <th>Contrato</th>
                    <th>Responsable</th>
                    <th>Observaciones</th>
                </tr>
                <?php 
                $result=mysqli_query($conexion,$query);
                while ($fila = mysqli_fetch_assoc($result)) {
                    ?><tr><td><?=$fila['razon_social']?></td><?php
                    ?><td><?=$fila['nombre_alumno']?></td><?php
                    ?><td><?=$fila['horario']?></td><?php
                    ?><td><?=$fila['curso']?></td><?php
                    ?><td><?=$fila['trabajo']?></td><?php
                    ?><td><?=$fila['contrato']?></td><?php
                    ?><td><?=$fila['nombre_responsable']?></td><?php
                    ?><td><?=$fila['observaciones']?></td><?php
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>
