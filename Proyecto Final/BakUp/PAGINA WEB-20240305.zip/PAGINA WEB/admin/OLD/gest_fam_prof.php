<?php 
include "../funciones.php";
cabecera("Gestionar Familias Profesionales","styles.css");
session_start();
// Establecer las variables de sesión con los valores del formulario actual

$conexion = conexion("172.20.131.102","ftc");
//Cargar lista de profesores
$q_lista = "SELECT idprofesores, CONCAT(nombre, ' ', apellidos) as 'nombre' FROM profesores ORDER BY nombre";
$r_lista = mysqli_query($conexion,$q_lista);

//Comienzo carga de arrays de profesores
$l_id = array();
$l_nombre = array();

while($row = $r_lista->fetch_assoc())
{
    $l_id[] = $row["idprofesores"];
    $l_nombre[] = $row["nombre"];
}
$long = count($l_id);
//Fin carga de arrays de profesores

if ($_SESSION['tipo_usuario'] == "admin") {
    nav_admin();
} else {
    nav_user();
}
if (isset($_POST['anadir'])) {
    $fam_pro_nom = $_POST['fam_pro_nom'];
    $fam_pro_coor = $_POST['fam_pro_coor'];
    $q = "INSERT INTO `fam_pro` (`nombre`, `coordinador`) VALUES ('$fam_pro_nom', '$fam_pro_coor');";
    $r =mysqli_query($conexion,$q);
}
$query = "SELECT f.idfam_pro, f.nombre, CONCAT(p.nombre, ' ', p.apellidos) as 'coordinador' FROM fam_pro f, profesores p WHERE f.coordinador = p.idprofesores ORDER BY f.nombre";
?>
    <div class="container">
        <h2>Lista de Familias Profesionales</h2>
        <?php
        ?>
        <br>
        <form action="gest_fam_prof.php" method="post">
            <table border="0">
                <tr>
                    <td><input type="text" name="fam_pro_nom" id="fam_pro_nom" placeholder="Nombre"></td>
                    <td>
                        <label for="fam_pro_coor">Coordinador:</label>
                        <select name="fam_pro_coor" id="fam_pro_coor">
                            <?php for($i = 0; $i < $long; $i++){ ?>
                            <option value="<?php echo $l_id[$i]; ?>"><?php echo $l_nombre[$i]; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td><button type="submit" name="anadir" id="anadir">Añadir</button></td>
                </tr>
            </table>
        </form>
        <div class="list-container">
            <table>
                <tr>
                    <th>Nombre</th>
                    <th>Coordinador</th>
                    <th>Gestionar</th>
                </tr>
                <?php 
                $result=mysqli_query($conexion,$query);
                while ($fila = mysqli_fetch_assoc($result)) {
                    ?><tr><td><?=$fila['nombre']?></td><?php
                    ?><td><?=$fila['coordinador']?></td><?php
                    ?><td><a href="gest_fam_prof_2.php?id=<?=$fila['idfam_pro']?>">Eliminar</a></td></tr><?php
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>