<?php 
include "../funciones.php";
cabecera("Gestionar Familias Profesionales","styles.css");
session_start();
// Establecer las variables de sesión con los valores del formulario actual

$conexion = conexion("172.20.131.102","ftc");
//Cargar lista de profesores
$q_lista = "SELECT idprofesores, CONCAT(nombre, ' ', apellidos) as 'nombre' FROM profesores ORDER BY nombre";
$r_lista = mysqli_query($conexion,$q_lista);

//Comienzo carga de arrays de profesores
$l_id = array();
$l_nombre = array();

while($row = $r_lista->fetch_assoc())
{
    $l_id[] = $row["idprofesores"];
    $l_nombre[] = $row["nombre"];
}
$long = count($l_id);
//Fin carga de arrays de profesores

//Cargar lista de profesores
$q_lista_c = "SELECT * FROM cic_form ORDER BY nombre";
$r_lista_c = mysqli_query($conexion,$q_lista_c);

//Comienzo carga de arrays de ciclos
$l_id_c = array();
$l_nombre_c = array();

while($row = $r_lista_c->fetch_assoc())
{
    $l_id_c[] = $row["idcic_form"];
    $l_nombre_c[] = $row["nombre"];
}
$long_c = count($l_id_c);
//Fin carga de arrays de profesores

if ($_SESSION['tipo_usuario'] == "admin") {
    nav_admin();
} else {
    nav_user();
}
if (isset($_POST['anadir'])) {
    $grup_nom = $_POST['grup_den'];
    $grup_abv = $_POST['grup_abr'];
    $ciclo = $_POST['ciclo'];
    $grup_tut = $_POST['grup_t'];
    $grup_tut_fct = $_POST['grup_t_fct'];
    $q = "INSERT INTO `grupos` (`abreviatura`, `denominacion`, `cic_form`, `tutor_fct`, `tutor_grupo`) VALUES ('$grup_abv', '$grup_nom', '$ciclo', '$grup_tut', '$grup_tut_fct');";
    $r =mysqli_query($conexion,$q);
}
$query = "SELECT g.idgrupos, g.abreviatura, g.denominacion, c.nombre AS cic_form,
       CONCAT(p1.nombre, ' ', p1.apellidos) AS tutor_fct,
       CONCAT(p2.nombre, ' ', p2.apellidos) AS tutor_grupo
       FROM grupos g
       JOIN profesores p1 ON g.tutor_fct = p1.idprofesores
       JOIN profesores p2 ON g.tutor_grupo = p2.idprofesores
       JOIN cic_form c ON g.cic_form = c.idcic_form
       ORDER BY g.denominacion;";
?>
    <div class="container">
        <h2>Lista de Familias Profesionales</h2>
        <?php
        ?>
        <br>
        <form action="gest_grup.php" method="post">
            <table border="0">
                <tr>
                    <td><input type="text" name="grup_den" id="grup_den" placeholder="Nombre"></td>
                    <td><input type="text" name="grup_abr" id="grup_abr" placeholder="Abreviatura"></td>
                    <td>
                        <label for="ciclo">Tutor del grupo:</label>
                        <select name="ciclo" id="ciclo">
                            <?php for($i = 0; $i < $long_c; $i++){ ?>
                            <option value="<?php echo $l_id_c[$i]; ?>"><?php echo $l_nombre_c[$i]; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td>
                        <label for="grup_t">Tutor del grupo:</label>
                        <select name="grup_t" id="grup_t">
                            <?php for($i = 0; $i < $long; $i++){ ?>
                            <option value="<?php echo $l_id[$i]; ?>"><?php echo $l_nombre[$i]; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td>
                        <label for="grup_t_fct">Tutor de las FCT:</label>
                        <select name="grup_t_fct" id="grup_t_fct">
                            <?php for($i = 0; $i < $long; $i++){ ?>
                            <option value="<?php echo $l_id[$i]; ?>"><?php echo $l_nombre[$i]; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td><button type="submit" name="anadir" id="anadir">Añadir</button></td>
                </tr>
            </table>
        </form>
        <div class="list-container">
            <table>
                <tr>
                    <th>Nombre</th>
                    <th>Abreviatura</th>
                    <th>Ciclo Formativo</th>
                    <th>Tutor</th>
                    <th>Tutor de FCT</th>
                    <th>Gestionar</th>
                </tr>
                <?php 
                $result=mysqli_query($conexion,$query);
                while ($fila = mysqli_fetch_assoc($result)) {
                    ?><tr><td><?=$fila['denominacion']?></td><?php
                    ?><td><?=$fila['abreviatura']?></td><?php
                    ?><td><?=$fila['cic_form']?></td><?php
                    ?><td><?=$fila['tutor_grupo']?></td><?php
                    ?><td><?=$fila['tutor_fct']?></td><?php
                    ?><td><a href="gest_grup_2.php?id=<?=$fila['idgrupos']?>">Eliminar</a></td></tr><?php
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>