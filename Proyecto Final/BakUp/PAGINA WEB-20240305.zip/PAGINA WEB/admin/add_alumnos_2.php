<?php
include("funciones.php");

$conexion = conexion("172.20.131.102","ftc");

$nombre = recoger('nombre');
$apellido = recoger('apellidos');
$fecha = recoger('fecha');
$dni = recoger('dni');
$email = recoger ('email');
$euskera = recoger('euskera');
$coche = recoger('coche'); 
$carnet = recoger('carnet');
$telefono = recoger('telefono');
$comentario = recoger('comentarios');

$q = "insert into alumnos(nombre, apellidos, fec_nac, dni, euskera, coche, carnet, tlfn, comentario) 
values ('$nombre', '$apellido', '$fecha', '$dni', '$euskera', '$coche', '$carnet', '$telefono', '$comentario')";

$resultado = mysqli_query($conexion, $q);

mysqli_close($conexion);

header("Location:add_alumnos.php");
?>
