<?php
// Función para limpiar y validar la entrada del usuario
function limpiar_entrada($entrada) {
    $entrada = trim($entrada);
    $entrada = stripslashes($entrada);
    $entrada = htmlspecialchars($entrada);
    return $entrada;
}
?>

<?php
// Función para obtener el nombre del coordinador
function obtenerNombreCoordinador($conexion, $id_coordinador) {
    $sql = "SELECT nombre FROM profesores WHERE idprofesores = $id_coordinador";
    $resultado = mysqli_query($conexion, $sql);

    if ($resultado && mysqli_num_rows($resultado) > 0) {
        $coordinador = mysqli_fetch_assoc($resultado);
        return $coordinador['nombre'];
    } else {
        return "Desconocido";
    }
}
?>