<?php
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id_grupo = $_GET['id'];

    // Include your connection function
    include("funciones.php");
    include "../funciones.php";

    // Use the connection function to establish a connection
    $conexion = conexion("172.20.131.102", "ftc");

    // Query to get details
    $sql = "SELECT g.*, c.nombre AS nombre_ciclo, CONCAT(p.nombre, ' ', p.apellidos) AS nombre_tutor_fct, CONCAT(p2.nombre, ' ', p2.apellidos) AS nombre_tutor_grupo 
            FROM grupos g
            LEFT JOIN cic_form c ON g.cic_form = c.idcic_form
            LEFT JOIN profesores p ON g.tutor_fct = p.idprofesores
            LEFT JOIN profesores p2 ON g.tutor_grupo = p2.idprofesores
            WHERE idgrupos = $id_grupo";
    $resultado = mysqli_query($conexion, $sql);

    if ($resultado && mysqli_num_rows($resultado) > 0) {
        $grupo = mysqli_fetch_assoc($resultado);

        // Generate HTML content for the popup
        echo "<h1>Detalles del Grupo <a href='javascript:void(0);' onclick='closePopup()'><img src='../img/cerrar.png' width='20px'></a></h1>";
        echo "<form>";
        echo "<b>Abreviatura: </b>" . $grupo['abreviatura'] . "<br>";
        echo "<b>Denominación: </b>" . $grupo['denominacion'] . "<br>";
        echo "<b>Ciclo Formativo: </b>" . $grupo['nombre_ciclo'] . "<br>";
        echo "<b>Tutor FCT: </b>" . $grupo['nombre_tutor_fct'] . "<br>";
        echo "<b>Tutor Grupo: </b>" . $grupo['nombre_tutor_grupo'] . "<br>";
        echo "</form>";
        echo "";
    } else {
        echo "Grupo no encontrado.";
    }

    // Close the connection
    mysqli_close($conexion);
} else {
    echo "ID de grupo inválido.";
}
?>
