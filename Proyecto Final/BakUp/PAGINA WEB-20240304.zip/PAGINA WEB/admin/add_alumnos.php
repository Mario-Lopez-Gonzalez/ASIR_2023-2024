<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="color.css">
</head>
<body>

<h2>Agregar alumnos</h2>

<form action="add_alumnos_2.php" method="post" class="form-container">
    <div class="form-row">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre" placeholder="Nombre" required value="">
        <label for="apellidos">Apellido:</label>
        <input type="text" name="apellidos" id="apellidos" placeholder="Apellido" required value="">
    </div>
    <div class="form-row">
        <label for="fecha">Fecha Nacimiento:</label>
        <input type="date" name="fecha" id="fecha" required value="">
        <label for="dni">DNI:</label>
        <input type="text" name="dni" placeholder="DNI" id="dni" required value="">
    </div>
    <div class="form-row">
        <label for="euskera">Euskera:</label>
        <select name="euskera" id="euskera">
            <option value="" selected>Ignorar</option>
            <option value="no">No</option>
            <option value="a1">A1</option>
            <option value="a2">A2</option>
            <option value="b1">B1</option>
            <option value="b2">B2</option>
            <option value="c1">C1</option>
            <option value="c2">C2</option>
        </select>
    </div>
    <div class="form-row">
        <label for="carnet">Carnet:</label>
        <input type="hidden" name="carnet" value="no">
        <input type="checkbox" name="carnet" id="carnet" value="si">
        <label for="coche">Coche:</label>
        <input type="hidden" name="coche" value="no">
        <input type="checkbox" name="coche" id="coche" value="si">
    </div>
    <div class="form-row">
        <label for="telefono">Telefono:</label>
        <input type="text" name="telefono" id="telefono" placeholder="Telefono" required value="">
    </div>
    <div class="form-row">
        <label for="comentarios">Comentarios:</label>
        <textarea name="comentarios" id="comentarios"></textarea>
    </div>
    <div class="form-row">
        <input type="submit" name="enviar" value="Agregar alumno">
    </div>
</form>

</body>
</html>
