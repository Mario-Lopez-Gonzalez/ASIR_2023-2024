<?php
include "funciones.php";
session_start();
cabecera("Grupos","ver_grup.css"); // Cambia "estilos.css" por tu archivo CSS si es diferente
nav_user();

// Llamar a la función para establecer la conexión
$conexion = conexion("172.20.131.102", "ftc");

// Consulta para obtener las opciones de ciclos formativos
$sql_ciclos = "SELECT idcic_form, nombre FROM cic_form";
$result_ciclos = mysqli_query($conexion, $sql_ciclos);

// Consulta para obtener las opciones de profesores
$sql_profesores = "SELECT idprofesores, CONCAT(nombre, ' ', apellidos) AS nombre_completo FROM profesores";
$result_profesores = mysqli_query($conexion, $sql_profesores);

// Consulta base para todos los grupos
$sql_base = "SELECT g.*, c.nombre AS nombre_ciclo, CONCAT(p.nombre, ' ', p.apellidos) AS nombre_tutor_fct, CONCAT(p2.nombre, ' ', p2.apellidos) AS nombre_tutor_grupo 
             FROM grupos g
             LEFT JOIN cic_form c ON g.cic_form = c.idcic_form
             LEFT JOIN profesores p ON g.tutor_fct = p.idprofesores
             LEFT JOIN profesores p2 ON g.tutor_grupo = p2.idprofesores";

// Verificar si se ha enviado el formulario
if (isset($_GET['buscar'])) {
    // Construir la condición WHERE dinámicamente si se aplican filtros
    $where = [];
    if (!empty($_GET['abreviatura'])) {
        $abreviatura = $_GET['abreviatura'];
        $where[] = "g.abreviatura LIKE '%$abreviatura%'";
    }

    if (!empty($_GET['denominacion'])) {
        $denominacion = $_GET['denominacion'];
        $where[] = "g.denominacion LIKE '%$denominacion%'";
    }

    // Agregar WHERE si hay condiciones
    if (!empty($where)) {
        $sql_base .= " WHERE " . implode(" AND ", $where);
    }
}

// Ejecutar consulta base
$resultado = mysqli_query($conexion, $sql_base);

?>

<body>
    <div class="container">
        <h1>Grupos</h1>
        <form method="GET">
            <input type="text" name="abreviatura" placeholder="Abreviatura...">
            <input type="text" name="denominacion" placeholder="Denominación...">
            <input type="submit" name="buscar" value="Buscar Grupo">
        </form>
        
        <!-- Resultados de la búsqueda -->
        <div id="resultados">
            <?php
            // Mostrar resultados
            if ($resultado && mysqli_num_rows($resultado) > 0) {
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    echo "<div class='grupo'>";
                    echo "<h3>" . $fila['abreviatura'] . " - " . $fila['denominacion'] . "</h3>";
                    echo "<p>Ciclo Formativo: " . $fila['nombre_ciclo'] . "</p>";
                    echo "<p>Tutor FCT: " . $fila['nombre_tutor_fct'] . "</p>";
                    echo "<p>Tutor Grupo: " . $fila['nombre_tutor_grupo'] . "</p>";
                    echo "<a href='ver_grup2.php?id=" . $fila['idgrupos'] . "'>Ver Detalles</a>";
                    echo "</div>";
                }
            } else {
                echo "No se encontraron resultados.";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
// Cerrar conexión al final del archivo
mysqli_close($conexion);
?>
