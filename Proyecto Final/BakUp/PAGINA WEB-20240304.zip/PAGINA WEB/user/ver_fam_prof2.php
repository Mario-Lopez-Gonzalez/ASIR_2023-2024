<?php
include "funciones.php";
session_start();
cabecera("Detalles de la Familia Profesional", "ver_fam_prof.css");
nav_user();

// Verificar si se recibió un ID válido
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id_fam_pro = $_GET['id'];

    // Llamar a la función para establecer la conexión
    $conexion = conexion("172.20.131.102", "ftc");

    // Consulta para obtener los detalles de la familia profesional
    $sql = "SELECT * FROM fam_pro WHERE idfam_pro = $id_fam_pro";
    $resultado = mysqli_query($conexion, $sql);

    if ($resultado && mysqli_num_rows($resultado) > 0) {
        $fam_pro = mysqli_fetch_assoc($resultado);
?>
<body>
    <div class="container">
        <h1>Detalles de la Familia Profesional</h1>
        <form>
            <label for="nombre">Nombre de Familia Profesional:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo $fam_pro['nombre']; ?>" readonly>

            <label for="coordinador">Coordinador:</label>
            <input type="text" id="coordinador" name="coordinador" value="<?php echo obtenerNombreCoordinador($conexion, $fam_pro['coordinador']); ?>" readonly>

            <!-- Puedes agregar más campos aquí según la estructura de tu tabla -->

            <a href="ver_fam_prof.php" class="btn-volver">Volver a Lista de Familias Profesionales</a>
        </form>
    </div>
</body>
</html>

<?php
    } else {
        echo "Familia profesional no encontrada.";
    }

    // Cerrar conexión al final del archivo
    mysqli_close($conexion);
} else {
    echo "ID de familia profesional inválido.";
}
?>
