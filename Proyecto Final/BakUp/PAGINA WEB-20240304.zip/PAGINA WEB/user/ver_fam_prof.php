<?php
include "funciones.php";
session_start();
cabecera("Lista de Familias Profesionales", "ver_fam_prof.css");
nav_user();

// Llamar a la función para establecer la conexión
$conexion = conexion("172.20.131.102", "ftc");

// Consulta para obtener todas las familias profesionales por defecto
$sql = "SELECT f.*, p.nombre AS nombre_coordinador 
        FROM fam_pro f
        LEFT JOIN profesores p ON f.coordinador = p.idprofesores";
$resultado = mysqli_query($conexion, $sql);

// Inicializar variables para la búsqueda
$nombre_fam_pro = "";
$coordinador = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Limpiar y validar los valores ingresados para la búsqueda
    $nombre_fam_pro = limpiar_entrada($_POST["nombre_fam_pro"]);
    $coordinador = limpiar_entrada($_POST["coordinador"]);

    // Consulta para buscar familias profesionales por nombre y/o coordinador
    $sql = "SELECT f.*, p.nombre AS nombre_coordinador 
            FROM fam_pro f
            LEFT JOIN profesores p ON f.coordinador = p.idprofesores
            WHERE f.nombre LIKE '%$nombre_fam_pro%' 
            AND p.nombre LIKE '%$coordinador%'";
    $resultado = mysqli_query($conexion, $sql);
}
?>

<body>
    <div class="container">
        <h1>Lista de Familias Profesionales</h1>

        <!-- Formulario de búsqueda -->
        <form method="POST" class="busqueda-form">
            <label for="nombre_fam_pro">Nombre Familiar:</label>
            <input type="text" id="nombre_fam_pro" name="nombre_fam_pro" value="<?php echo $nombre_fam_pro; ?>" placeholder="Nombre...">
            
            <label for="coordinador">Coordinador:</label>
            <input type="text" id="coordinador" name="coordinador" value="<?php echo $coordinador; ?>" placeholder="Nombre del Coordinador...">
            
            <input type="submit" value="Buscar Familia Profesional">
        </form>

        <!-- Resultados de la búsqueda -->
        <div id="resultados">
            <?php
            // Mostrar resultados de la búsqueda
            if ($resultado && mysqli_num_rows($resultado) > 0) {
                while ($fam_pro = mysqli_fetch_assoc($resultado)) {
                    echo "<div class='familia-profesional'>";
                    echo "<h3>" . $fam_pro['nombre'] . "</h3>";
                    echo "<p><strong>Coordinador:</strong> " . $fam_pro['nombre_coordinador'] . "</p>";
                    echo "<a href='ver_fam_prof2.php?id=" . $fam_pro['idfam_pro'] . "'>Ver Detalles</a>";
                    echo "</div>";
                }
            } else {
                echo "No se encontraron resultados.";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
// Cerrar conexión al final del archivo
mysqli_close($conexion);
?>
