<?php
include "funciones.php";
session_start();
cabecera("Ver ciclo formativo", "ver_cic.css");
nav_user();

// Llamar a la función para establecer la conexión
$conexion = conexion("172.20.131.102", "ftc");
?>
<style>
    .container {
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    form {
        display: flex;
        flex-direction: column;
    }

    input,
    select {
        margin-bottom: 10px;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    input[type="submit"] {
        background-color: #007bff;
        color: #fff;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background-color: #0056b3;
    }

    #popup {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%); /* Center horizontally and vertically */
        width: 80%; /* Adjust the width as needed */
        max-width: 600px; /* Set a maximum width if necessary */
        box-shadow: 0 0 21px rgba(0, 0, 0, 0.8); /* Dark shadow effect */
        border-radius: 15px; /* Rounded corners */
        z-index: 2; /* Ensure the popup is on top of other content */
    }

    #popup-content {
        background: #fff; /* white background for the content area */
        padding: 20px;
        border-radius: 9px;
        text-align: left;
        max-width: 100%; /* Allow content to be as wide as the popup */
    }
</style>
<body>
    <div class="container">
        <h1>Ciclos Formativos</h1>
        <form method="GET">
            <input type="text" name="nombre" placeholder="Nombre...">
            <select name="nivel">
                <option value="">Todos los niveles</option>
                <?php
                // Obtener opciones para 'nivel' desde la base de datos
                $sql_nivel = "SELECT DISTINCT nivel FROM cic_form";
                $result_nivel = mysqli_query($conexion, $sql_nivel);

                if ($result_nivel->num_rows > 0) {
                    while ($row_nivel = mysqli_fetch_assoc($result_nivel)) {
                        echo "<option value='" . $row_nivel['nivel'] . "'>" . $row_nivel['nivel'] . "</option>";
                    }
                }
                ?>
            </select>
            <select name="fam_pro">
                <option value="">Todas las familias profesionales</option>
                <?php
                // Obtener opciones para 'fam_pro' desde la tabla fam_pro
                $sql_fam_pro = "SELECT idfam_pro, nombre FROM fam_pro";
                $result_fam_pro = mysqli_query($conexion, $sql_fam_pro);

                if ($result_fam_pro->num_rows > 0) {
                    while ($row_fam_pro = mysqli_fetch_assoc($result_fam_pro)) {
                        echo "<option value='" . $row_fam_pro['idfam_pro'] . "'>" . $row_fam_pro['nombre'] . "</option>";
                    }
                }
                ?>
            </select>
            <input type="submit" value="Buscar Ciclo">
        </form>        
        <br>
        <div id="resultados">
            <?php
            // Consulta base
            $sql = "SELECT c.*, f.nombre AS nombre_fam_pro FROM cic_form c
                    INNER JOIN fam_pro f ON c.fam_pro = f.idfam_pro";

            // Construir la condición WHERE dinámicamente si se aplican filtros
            $where = [];
            if (!empty($_GET['nombre'])) {
                $nombre = $_GET['nombre'];
                $where[] = "c.nombre LIKE '%$nombre%'";
            }

            if (!empty($_GET['nivel'])) {
                $nivel = $_GET['nivel'];
                $where[] = "c.nivel = '$nivel'";
            }

            if (!empty($_GET['fam_pro'])) {
                $fam_pro = $_GET['fam_pro'];
                $where[] = "c.fam_pro = '$fam_pro'";
            }

            // Agregar WHERE si hay condiciones
            if (!empty($where)) {
                $sql .= " WHERE " . implode(" AND ", $where);
            }

            // Ejecutar consulta
            $resultado = mysqli_query($conexion, $sql);

            // Mostrar resultados
            if ($resultado && mysqli_num_rows($resultado) > 0) {
                while ($fila = mysqli_fetch_assoc($resultado)) {
                    echo "<div class='ciclo'>";
                    echo "<h3>" . $fila['nombre'] . "</h3>";
                    echo "<p>Abreviatura: " . $fila['abreviatura'] . "</p>";
                    echo "<a href='javascript:void(0);' onclick='openPopup(" . $fila['idcic_form'] . ")'>Ver Detalles</a>";
                    echo "</div>";
                }
            } else {
                echo "No se encontraron resultados.";
            }
            ?>
        </div>
    </div>
    <div id="popup">
        <div id="popup-content"></div>
    </div>
    <script>
        // Function to open the popup
        function openPopup(id) {
            // Use AJAX to fetch the details and update the popup content
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("popup-content").innerHTML = this.responseText;
                    document.getElementById("popup").style.display = "block";
                }
            };
            xmlhttp.open("GET", "ver_cic_for_popup.php?id=" + id, true);
            xmlhttp.send();
        }

        // Function to close the popup
        function closePopup() {
            document.getElementById("popup").style.display = "none";
        }
    </script>
</body>
</html>
<?php
// Cerrar conexión al final del archivo
mysqli_close($conexion);
?>
