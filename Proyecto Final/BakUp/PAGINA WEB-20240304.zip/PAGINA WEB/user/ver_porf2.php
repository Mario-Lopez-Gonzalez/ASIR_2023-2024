<?php
include "funciones.php";
session_start();
cabecera("Detalles del Profesor", "ver_porf.css");
nav_user();

// Verificar si se recibió un ID válido
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id_profesor = $_GET['id'];

    // Llamar a la función para establecer la conexión
    $conexion = conexion("172.20.131.102", "ftc");

    // Consulta para obtener los detalles del profesor
    $sql = "SELECT * FROM profesores WHERE codigo = $id_profesor";
    $resultado = mysqli_query($conexion, $sql);

    if ($resultado && mysqli_num_rows($resultado) > 0) {
        $profesor = mysqli_fetch_assoc($resultado);
?>
<body>
    <div class="container">
        <h1>Detalles del Profesor</h1>
        <form>
            <label for="codigo">Código:</label>
            <input type="text" id="codigo" name="codigo" value="<?php echo $profesor['codigo']; ?>" readonly>

            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo $profesor['nombre']; ?>" readonly>

            <label for="apellidos">Apellidos:</label>
            <input type="text" id="apellidos" name="apellidos" value="<?php echo $profesor['apellidos']; ?>" readonly>

            <label for="tlfn">Teléfono:</label>
            <input type="text" id="tlfn" name="tlfn" value="<?php echo $profesor['tlfn']; ?>" readonly>

            <label for="email">Email:</label>
            <input type="text" id="email" name="email" value="<?php echo $profesor['email']; ?>" readonly>

            <a href="ver_porf.php" class="btn-volver">Volver a Lista de Profesores</a>
        </form>
    </div>
</body>
</html>

<?php
    } else {
        echo "Profesor no encontrado.";
    }

    // Cerrar conexión al final del archivo
    mysqli_close($conexion);
} else {
    echo "ID de profesor inválido.";
}
?>
