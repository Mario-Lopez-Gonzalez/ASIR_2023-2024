document.addEventListener("DOMContentLoaded", function () {
    // Obtener elementos
    const popupContainer = document.querySelector('.popup-container');
    const popupClose = document.querySelector('.popup-close');
    const detallesLink = document.querySelector('.popup-trigger');

    // Mostrar la ventana flotante al hacer clic en "Ver Detalles"
    detallesLink.addEventListener('click', function (event) {
        event.preventDefault();
        popupContainer.style.display = 'block';
    });

    // Cerrar la ventana flotante al hacer clic en la X
    popupClose.addEventListener('click', function () {
        popupContainer.style.display = 'none';
    });

    // Cerrar la ventana flotante al hacer clic fuera de ella
    window.addEventListener('click', function (event) {
        if (event.target === popupContainer) {
            popupContainer.style.display = 'none';
        }
    });
});
