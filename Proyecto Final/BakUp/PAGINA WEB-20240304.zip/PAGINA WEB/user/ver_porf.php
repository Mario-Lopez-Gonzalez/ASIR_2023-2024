<?php
include "funciones.php";
session_start();
cabecera("Lista de Profesores", "ver_porf.css");
nav_user();

// Llamar a la función para establecer la conexión
$conexion = conexion("172.20.131.102", "ftc");

// Consulta para obtener todos los profesores por defecto
$sql = "SELECT * FROM profesores";
$resultado = mysqli_query($conexion, $sql);

// Inicializar variable para la búsqueda
$busqueda = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Limpiar y validar el valor ingresado para la búsqueda
    $busqueda = limpiar_entrada($_POST["busqueda"]);

    // Consulta para buscar profesores por código, nombre o apellido
    $sql = "SELECT * FROM profesores 
            WHERE codigo LIKE '%$busqueda%' 
            OR nombre LIKE '%$busqueda%' 
            OR apellidos LIKE '%$busqueda%'";
    $resultado = mysqli_query($conexion, $sql);
}
?>

<body>
    <div class="container">
        <h1>Lista de Profesores</h1>

        <!-- Formulario de búsqueda -->
        <form method="POST" class="busqueda-form">
            <label for="busqueda">Buscar:</label>
            <input type="text" id="busqueda" name="busqueda" value="<?php echo $busqueda; ?>" placeholder="Código, Nombre o Apellido...">
            <input type="submit" value="Buscar Profesor">
        </form>

        <!-- Resultados de la búsqueda -->
        <div id="resultados">
            <?php
            // Mostrar resultados de la búsqueda
            if ($resultado && mysqli_num_rows($resultado) > 0) {
                while ($profesor = mysqli_fetch_assoc($resultado)) {
                    echo "<div class='profesor'>";
                    echo "<p><strong>Código:</strong> " . $profesor['codigo'] . "</p>";
                    echo "<p><strong>Nombre:</strong> " . $profesor['nombre'] . " " . $profesor['apellidos'] . "</p>";
                    echo "<p><strong>Teléfono:</strong> " . $profesor['tlfn'] . "</p>";
                    echo "<p><strong>Email:</strong> " . $profesor['email'] . "</p>";
                    echo "<a href='ver_porf2.php?id=" . $profesor['codigo'] . "'>Ver Detalles</a>";
                    echo "</div>";
                }
            } else {
                echo "No se encontraron resultados.";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
// Cerrar conexión al final del archivo
mysqli_close($conexion);
?>
