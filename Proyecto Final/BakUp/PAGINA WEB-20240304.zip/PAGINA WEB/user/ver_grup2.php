<?php
include "funciones.php";
session_start();
cabecera("Detalles del Grupo","ver_grup.css");
nav_user();

// Verificar si se recibió un ID válido
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id_grupo = $_GET['id'];

    // Llamar a la función para establecer la conexión
    $conexion = conexion("172.20.131.102", "ftc");

    // Consulta para obtener los detalles del grupo
    $sql_grupo = "SELECT g.*, c.nombre AS nombre_ciclo, CONCAT(p.nombre, ' ', p.apellidos) AS nombre_tutor_fct, 
                CONCAT(p2.nombre, ' ', p2.apellidos) AS nombre_tutor_grupo 
                FROM grupos g
                INNER JOIN cic_form c ON g.cic_form = c.idcic_form
                INNER JOIN profesores p ON g.tutor_fct = p.idprofesores
                INNER JOIN profesores p2 ON g.tutor_grupo = p2.idprofesores
                WHERE g.idgrupos = $id_grupo";

    $resultado_grupo = mysqli_query($conexion, $sql_grupo);

    if ($resultado_grupo && mysqli_num_rows($resultado_grupo) > 0) {
        $grupo = mysqli_fetch_assoc($resultado_grupo);
?>
<body>
    <div class="container">
        <h1>Detalles del Grupo</h1>
        <form>
            <label for="abreviatura">Abreviatura:</label>
            <input type="text" id="abreviatura" name="abreviatura" value="<?php echo $grupo['abreviatura']; ?>" readonly>

            <label for="denominacion">Denominación:</label>
            <input type="text" id="denominacion" name="denominacion" value="<?php echo $grupo['denominacion']; ?>" readonly>

            <label for="ciclo">Ciclo Formativo:</label>
            <input type="text" id="ciclo" name="ciclo" value="<?php echo $grupo['nombre_ciclo']; ?>" readonly>

            <label for="tutor_fct">Tutor FCT:</label>
            <input type="text" id="tutor_fct" name="tutor_fct" value="<?php echo $grupo['nombre_tutor_fct']; ?>" readonly>

            <label for="tutor_grupo">Tutor Grupo:</label>
            <input type="text" id="tutor_grupo" name="tutor_grupo" value="<?php echo $grupo['nombre_tutor_grupo']; ?>" readonly>
        </form>

        <a href="ver_grup.php">Volver atrás</a>
    </div>
</body>
</html>

<?php
    } else {
        echo "Grupo no encontrado.";
    }

    // Cerrar conexión al final del archivo
    mysqli_close($conexion);
} else {
    echo "ID de grupo inválido.";
}
?>
