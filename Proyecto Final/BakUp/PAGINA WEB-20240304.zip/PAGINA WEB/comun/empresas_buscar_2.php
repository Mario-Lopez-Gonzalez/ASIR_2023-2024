<?php 
include "../funciones.php";
include "funciones_com.php";
cabecera("Buscar Alumnado","styles.css");
session_start();
$conexion = conexion("172.20.131.102","ftc");
$id = $_GET['id'];
$query = "SELECT * FROM empresas WHERE idempresas='$id'";
$result = mysqli_query($conexion,$query);
$fila = mysqli_fetch_assoc($result);
if ($_SESSION['tipo_usuario'] == "admin") {
    nav_admin();
} else {
    nav_user();
}
?>
    <div class="container">
        <h2>Más información sobre <?=$fila['razon_social']?></h2>
        <br>
        <div class="list-container">
            <table>
                <?php 
                $result=mysqli_query($conexion,$query);
                while ($fila = mysqli_fetch_assoc($result)) {
                    ?><tr><td>Nombre:</td><td><?=$fila['razon_social']?></td><?php
                    ?><tr><td>NIF:</td><td><?=$fila['nif']?></td><?php
                    ?><tr><td>Dirección:</td><td><?=$fila['direccion']?></td><?php
                    ?><tr><td>Provincia:</td><td><?=$fila['provincia']?></td><?php
                    ?><tr><td>Población:</td><td><?=$fila['poblacion']?></td><?php
                    ?><tr><td>Código Postal:</td><td><?=$fila['codigo_postal']?></td><?php
                    ?><tr><td>Teléfono:</td><td><?=$fila['tlfn']?></td><?php
                    ?><tr><td>Fax:</td><td><?=$fila['fax']?></td><?php
                    ?><tr><td>Email:</td><td><?=$fila['email']?></td><?php
                    ?><tr><td>Titularidad:</td><td><?=$fila['titularidad']?></td><?php
                    ?><tr><td>Representante:</td><td><?=$fila['representante']?></td><?php
                    ?><tr><td>Teléfono representante:</td><td><?=$fila['tlfn_rep']?></td><?php
                    ?><tr><td>Email representante:</td><td><?=$fila['email_rep']?></td><?php
                    ?><tr><td>Persona de contacto:</td><td><?=$fila['p_contacto']?></td><?php
                    ?><tr><td>Teléfono de la persona de contacto:</td><td><?=$fila['tlfn_contacto']?></td><?php
                    ?><tr><td>Email de la persona de contacto:</td><td><?=$fila['email_contacto']?></td><?php
                    ?><tr><td>Actividad:</td><td><?=$fila['actividad']?></td><?php
                    ?><tr><td>CNAE:</td><td><?=$fila['cnae']?></td><?php
                    ?><tr><td>Número de Trabajadores:</td><td><?=$fila['n_trabajadores']?></td><?php
                    ?><tr><td>KMs del Centro:</td><td><?=$fila['kms']?></td><?php
                    ?><tr><td>Horario:</td><td><?=$fila['horario']?></td><?php
                    ?><tr><td>Convenio:</td><td><?=$fila['convenio']?></td><?php
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>