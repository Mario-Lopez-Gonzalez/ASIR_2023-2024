<?php 
include "../funciones.php";
include "funciones_com.php";
cabecera("Buscar Alumnado","styles.css");
session_start();

// Establecer las variables de sesión con los valores del formulario actual
$_SESSION['busqueda'] = recoger("busqueda");
$_SESSION['euskera'] = recoger("euskera");
$_SESSION['coche'] = recoger("coche");
$_SESSION['carnet'] = recoger("carnet");

$conexion = conexion("172.20.131.102","ftc");
$query = "SELECT * FROM alumnos";

if ($_SESSION['tipo_usuario'] == "admin") {
    nav_admin();
} else {
    nav_user();
}
if (isset($_POST['mostrar'])) {
    $_SESSION['busqueda'] = "";
    $_SESSION['euskera'] = "";
    $_SESSION['coche'] = "";
    $_SESSION['carnet'] = "";
}
if (isset($_POST['buscar'])) {
    $busqueda = $_POST['busqueda'];
    $euskera = $_POST['euskera'];
    $coche = $_POST['coche'];
    $carnet = $_POST['carnet'];
    $query = "SELECT * FROM alumnos WHERE (dni LIKE '%$busqueda%' OR nombre LIKE '%$busqueda%' OR email LIKE '%$busqueda%')";
    if ($euskera != "") {
        $query = $query." AND euskera = '$euskera'";
    }
    if ($coche != "") {
        $query = $query." AND coche = '$coche'";
    }
    if ($carnet != "") {
        $query = $query." AND carnet = '$carnet'";
    }
}
?>
    <div class="container">
        <h2>Lista de Alumnos</h2>
        <br>
        <form action="alumnos_buscar.php" method="post">
            <table border="0">
                <tr>
                    <td><input type="text" name="busqueda" id="busqueda" placeholder="DNI / Nombre / Email" value="<?php echo $_SESSION['busqueda']; ?>"></td>
                    <td><label for="euskera">Euskera:</label>
                        <select name="euskera" id="euskera">
                            <option value="" selected>Ignorar</option>
                            <option value="no" <?php s_poner_selected("euskera","no"); ?>>No</option>
                            <option value="a1" <?php s_poner_selected("euskera","a1"); ?>>A1</option>
                            <option value="a2" <?php s_poner_selected("euskera","a2"); ?>>A2</option>
                            <option value="b1" <?php s_poner_selected("euskera","b1"); ?>>B1</option>
                            <option value="b2" <?php s_poner_selected("euskera","b2"); ?>>B2</option>
                            <option value="c1" <?php s_poner_selected("euskera","c1"); ?>>C1</option>
                            <option value="c2" <?php s_poner_selected("euskera","c2"); ?>>C2</option>
                        </select>
                    </td>
                    <td>
                        <label for="coche">Coche:</label>
                        <select name="coche" id="coche">
                            <option value="" selected>Ignorar</option>
                            <option value="si" <?php s_poner_selected("coche","si"); ?>>Si</option>
                            <option value="no" <?php s_poner_selected("coche","no"); ?>>No</option>
                        </select>
                    </td>
                    <td>
                        <label for="carnet">Carnet:</label>
                        <select name="carnet" id="carnet">
                            <option value="" selected>Ignorar</option>
                            <option value="si" <?php s_poner_selected("carnet","si"); ?>>Si</option>
                            <option value="no" <?php s_poner_selected("carnet","no"); ?>>No</option>
                        </select>
                    </td>
                    <td><button type="submit" name="buscar" id="buscar">Buscar Alumnos</button></td>
                    <td><button type="submit" name="mostrar" id="Mostrar todos">Mostrar todos</button></td>
                </tr>
            </table>
        </form>
        <div class="list-container">
            <table>
                <tr>
                    <th>DNI</th>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>Fecha de nacimiento</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                    <th>Euskera</th>
                    <th>Coche</th>
                    <th>Carnet</th>
                    <th>Comentario</th>
                </tr>
                <?php 
                $result=mysqli_query($conexion,$query);
                while ($fila = mysqli_fetch_assoc($result)) {
                    ?><tr><td><?=$fila['dni']?></td><?php
                    ?><td><?=$fila['nombre']?></td><?php
                    ?><td><?=$fila['apellidos']?></td><?php
                    ?><td><?=$fila['fec_nac']?></td><?php
                    ?><td><?=$fila['tlfn']?></td><?php
                    ?><td><?=$fila['email']?></td><?php
                    ?><td><?=$fila['euskera']?></td><?php
                    ?><td><?=$fila['coche']?></td><?php
                    ?><td><?=$fila['carnet']?></td><?php
                    ?><td><?=$fila['comentario']?></td></tr><?php
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>
