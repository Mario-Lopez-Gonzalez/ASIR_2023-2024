<?php 
include "funciones.php";
session_start();
$conexion = conexion("172.20.131.102","ftc");
cabecera("Registro","Iniciar sesión");

// Variable para controlar la visualización del mensaje de error
$error = false;

if (isset($_SESSION['tipo_usuario'])) {
    if ($fila['tipo_usuario']=="admin") {
                header("Location: index_admin.php");
            }
            else
            {
                header("Location: index_user.php");
            }
    ?>
    <a href="logout.php">Cerrar sesion</a>
    <?php
} else {
    if (isset($_POST['enviar'])) {
        $q = "SELECT * from usuarios WHERE nombre='".$_POST['usuario']."'";
        $r = mysqli_query($conexion, $q) or die(mysqli_error());
        $fila = mysqli_fetch_assoc($r);
        if (isset($fila) && $_POST['password']==$fila['password']) {
            echo "Login correcto, eres ".$fila['tipo_usuario'];
            $_SESSION['usuario']=$fila['nombre'];
            $_SESSION['tipo_usuario']=$fila['tipo_usuario'];
            if ($fila['tipo_usuario']=="admin") {
                header("Location: index_admin.php");
            }
            else
            {
                header("Location: index_user.php");
            }
            // Redirigir al index.php con header("Location: index.php");
        } else {
            // Configuración del error para mostrar el mensaje de contraseña incorrecta
            $error = true;
        }
    }
    // Mostrar mensaje de error solo si $error es verdadero
    if ($error) {
        echo "<h2 style='color: red;'>Contraseña o usuario incorrectos</h2>";
    }
?>
    <form action="login.php" method="POST">
        <label for="usuario">Usuario:</label><br>
        <input type="text" id="usuario" name="usuario" required><br>
        <label for="password">Contraseña:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" name="enviar" id="enviar" value="Iniciar sesión">
    </form>
<?php
}
?>
