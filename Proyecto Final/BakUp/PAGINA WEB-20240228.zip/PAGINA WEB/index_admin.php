<?php
include "funciones.php";
cabecera("Index_admin");
nav_admin();
?>
</body>
</html>