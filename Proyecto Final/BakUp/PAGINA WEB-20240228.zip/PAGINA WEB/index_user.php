<?php
include "funciones.php";
cabecera("Index_user");
nav_user();
?>
</body>
</html>