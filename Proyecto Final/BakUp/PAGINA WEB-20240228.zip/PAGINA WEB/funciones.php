<?php
/*
Crea la cabecera y parte del cuerpo.
Entrada: titulo de pagina (str)
Salida: no
Requiere: etiquetas </body> y </html> al final del bloque donde se invoca
*/
function cabecera($title)
{
	?>
	<!DOCTYPE html>
	<html lang="es">
	<head>
	    <meta charset="UTF-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <title><?php echo $title ?></title>
	    <link rel="stylesheet" href="styles.css">
	</head>
	<body>
	<?php
}

function nav_user()
{
?>
	<!-- Barra morada -->
    <div class="purple-bar">
        <!-- Logo y título -->
        <div class="logo">
            <strong>Gestión FCT</strong>
        </div>

        <!-- Elementos de búsqueda/navegación -->
        <nav>
            <ul>
                <li><a href="#">Alumnos</a>
                    <ul>
                        <li><a href="#">Buscar alumnos</a></li>
                        <li><a href="#">Asignaciones</a></li>
                    </ul>
                </li>
                <li><a href="#">Empresas</a>
                    <ul>
                        <li><a href="#">Buscar empresas</a></li>
                        <li><a href="#">Asignaciones</a></li>
                    </ul>
                </li>
                <li><a href="#">Información</a>
                    <ul>
                        <li><a href="#">Ver ciclos formativos</a></li>
                        <li><a href="#">Ver grupos</a></li>
                        <li><a href="#">Ver profesores</a></li>
                        <li><a href="#">Ver familias profesionales</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div class="logo">
            <div class="logout">
                <strong><a href="logout.php">Cerrar Sesión</a></strong>
            </div>
        </div>
        <!-- Cerrar Sesión -->
        
    </div>

    <!-- Contenido de la página -->
    <div class="content">
        <!-- Tu contenido aquí -->
    </div>
<?php
}

function nav_admin()
{
?>
	<!-- Barra morada -->
    <div class="purple-bar">
        <!-- Logo y título -->
        <div class="logo">
            <strong>Gestión FCT</strong>
        </div>

        <!-- Elementos de búsqueda/navegación -->
        <nav>
            <ul>
                <li><a href="#">Alumnos</a>
                    <ul>
                        <li><a href="#">Buscar alumnos</a></li>
                        <li><a href="#">Asignaciones</a></li>
                    </ul>
                </li>
                <li><a href="#">Empresas</a>
                    <ul>
                        <li><a href="#">Buscar empresas</a></li>
                        <li><a href="#">Asignaciones</a></li>
                    </ul>
                </li>
                <li><a href="#">Información</a>
                    <ul>
                        <li><a href="#">Ver ciclos formativos</a></li>
                        <li><a href="#">Ver grupos</a></li>
                        <li><a href="#">Ver profesores</a></li>
                        <li><a href="#">Ver familias profesionales</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div class="logo">
            <div class="logout">
                <strong><a href="logout.php">Cerrar Sesión</a></strong>
            </div>
        </div>
        <!-- Cerrar Sesión -->
        
    </div>

    <!-- Contenido de la página -->
    <div class="content">
        <!-- Tu contenido aquí -->
    </div>
<?php
}

/*
Comprueba que el input contenga información
Entrada: nombre del input (str)
Salida: valor del input (str) [Devuelve empty str si NULL]
Requiere: nada
*/
function recoger($a)
{
	if(isset($_POST[$a]))
	{
		$tmp=$_POST[$a];
	}
	else
	{
		$tmp="";
	}
	return $tmp;
}

function poner($a)
{
	if(isset($_POST[$a]))
	{
		echo $_POST[$a];
	}
}

/*
Comprueba si existe un valor en el control especificado y si coincide con el segundo argumento devuelve la palabra 'checked'.
Útil para activar checkboxes y radiobuttons
Entrada: nombre del control (str), valor a comparar (str)
Salida: no
Requiere: nada
*/
function poner_checked($c,$v)
{
	if (isset($_POST[$c]) && $_POST[$c] == $v) {
		echo 'checked';
	}
}

/*
Comprueba si existe un valor en el control especificado y si coincide con el segundo argumento devuelve la palabra 'checked'.
Útil para activar options de select
Entrada: nombre del control (str), valor a comparar (str)
Salida: no
Requiere: nada
*/
function poner_selected($c,$v)
{
	if (isset($_POST[$c]) && $_POST[$c] == $v) {
		echo 'selected';
	}
}

/*
Crea la conexión con la base de datos al esquema del parametro.
Entrada: nombre del esquema (str)
Salida: objeto de la conexión
Requiere: nada
*/
function conexion($ip,$db)
{
	$conexion = mysqli_connect($ip, "root");
if (!$conexion){
	echo "Error:No se pudo conectar a MySQL.";
	echo "errno de depuración: ". mysqli_connect_errno();
	echo "error de depuración: ". mysqli_connect_error();
	exit;
}
mysqli_select_db($conexion, $db) or die ("No se puede seleccionar la base de datos");
	return $conexion;
}
?>