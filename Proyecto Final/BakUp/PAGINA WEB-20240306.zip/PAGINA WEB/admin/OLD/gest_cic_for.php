<?php 
include "../funciones.php";
cabecera("Gestionar Ciclos Formativos","styles.css");
session_start();
// Establecer las variables de sesión con los valores del formulario actual

$conexion = conexion("172.20.131.102","ftc");
//Cargar lista de fam_pro
$q_lista = "SELECT * FROM fam_pro ORDER BY nombre";
$r_lista = mysqli_query($conexion,$q_lista);

//Comienzo carga de arrays de familias profesionales
$l_id = array();
$l_nombre = array();

while($row = $r_lista->fetch_assoc())
{
    $l_id[] = $row["idfam_pro"];
    $l_nombre[] = $row["nombre"];
}
$long = count($l_id);
//Fin carga de arrays de familias profesionales

if ($_SESSION['tipo_usuario'] == "admin") {
    nav_admin();
} else {
    nav_user();
}
if (isset($_POST['anadir'])) {
    $cic_form_nom = $_POST['cic_form_nom'];
    $cic_form_abr = $_POST['cic_form_abr'];
    $cic_form_niv = $_POST['cic_form_niv'];
    $cic_form_fam_pro = $_POST['cic_form_fam_pro'];
    $q = "INSERT INTO `cic_form` (`nombre`, `abreviatura`, `nivel`, `fam_pro`) VALUES ('$cic_form_nom', '$cic_form_abr', '$cic_form_niv', '$cic_form_fam_pro');";
    $r =mysqli_query($conexion,$q);
}
$query = "SELECT c.idcic_form, c.nombre, c.abreviatura, c.nivel, f.nombre as 'fam_pro' FROM cic_form c, fam_pro f WHERE c.fam_pro = f.idfam_pro ORDER BY c.nombre";
?>
    <div class="container">
        <h2>Lista de Ciclos Formativos</h2>
        <?php
        ?>
        <br>
        <form action="gest_cic_for.php" method="post">
            <table border="0">
                <tr>
                    <td><input type="text" name="cic_form_nom" id="cic_form_nom" placeholder="Nombre"></td>
                    <td><input type="text" name="cic_form_abr" id="cic_form_nom" placeholder="Abreviatura" ></td>
                    <td>
                        <label for="cic_form_niv">Nivel:</label>
                        <select name="cic_form_niv" id="cic_form_niv">
                            <option value="FPB">FPB</option>
                            <option value="GM">GM</option>
                            <option value="GS">GS</option>
                        </select>
                    </td>
                    <td>
                        <label for="cic_form_fam_pro">Familia Profesional:</label>
                        <select name="cic_form_fam_pro" id="cic_form_fam_pro">
                            <?php for($i = 0; $i < $long; $i++){ ?>
                            <option value="<?php echo $l_id[$i]; ?>"><?php echo $l_nombre[$i]; ?></option>
                            <?php } ?>
                        </select>
                    </td>
                    <td><button type="submit" name="anadir" id="anadir">Añadir</button></td>
                </tr>
            </table>
        </form>
        <div class="list-container">
            <table>
                <tr>
                    <th>Nombre</th>
                    <th>Abreviatura</th>
                    <th>Nivel</th>
                    <th>Familia Profesional</th>
                    <th>Gestionar</th>
                </tr>
                <?php 
                $result=mysqli_query($conexion,$query);
                while ($fila = mysqli_fetch_assoc($result)) {
                    ?><tr><td><?=$fila['nombre']?></td><?php
                    ?><td><?=$fila['abreviatura']?></td><?php
                    ?><td><?=$fila['nivel']?></td><?php
                    ?><td><?=$fila['fam_pro']?></td><?php
                    ?><td><a href="gest_cic_for_2.php?id=<?=$fila['idcic_form']?>">Eliminar</a></td></tr><?php
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>