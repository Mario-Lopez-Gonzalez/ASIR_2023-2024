<?php 
include "../funciones.php";
cabecera("Gestionar Profesores","styles.css");
session_start();
// Establecer las variables de sesión con los valores del formulario actual

$conexion = conexion("172.20.131.102","ftc");
$q_highest = "SELECT MAX(codigo) AS max FROM profesores";
$r_highest = mysqli_query($conexion,$q_highest);
$f_highest = mysqli_fetch_assoc($r_highest);
$max = $f_highest['max'] + 1;
if ($_SESSION['tipo_usuario'] == "admin") {
    nav_admin();
} else {
    nav_user();
}
if (isset($_POST['anadir'])) {
    $prof_cod = $_POST['prof_cod'];
    $prof_nom = $_POST['prof_nom'];
    $prof_ape = $_POST['prof_ape'];
    $prof_tlfn = $_POST['prof_tlfn'];
    $prof_email = $_POST['prof_email'];
    $q = "INSERT INTO `profesores` (`codigo`, `nombre`, `apellidos`, `tlfn`, `email`) VALUES ('$prof_cod', '$prof_nom', '$prof_ape', '$prof_tlfn', '$prof_email');";
    $r =mysqli_query($conexion,$q);
}
$query = "SELECT * FROM profesores";
?>
    <div class="container">
        <h2>Lista de Profesores</h2>
        <?php
        ?>
        <br>
        <form action="gest_prof.php" method="post">
            <table border="0">
                <tr>
                    <td><label for="prof_cod">Código del Profesor:</label><input type="number" name="prof_cod" id="prof_cod" min="<?=$max?>"></td>
                    <td><input type="text" name="prof_nom" id="prof_nom" placeholder="Nombre"></td>
                    <td><input type="text" name="prof_ape" id="prof_ape" placeholder="Apellidos"></td>
                    <td><input type="text" name="prof_tlfn" id="prof_tlfn" placeholder="Télefono (XXXXXXXXX)" pattern="[0-9]{9}"></td>
                    <td><input type="email" name="prof_email" id="prof_email" placeholder="Email"></td>
                    <td><button type="submit" name="anadir" id="anadir">Añadir</button></td>
                </tr>
            </table>
        </form>
        <div class="list-container">
            <table>
                <tr>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                    <th>Gestionar</th>
                </tr>
                <?php 
                $result=mysqli_query($conexion,$query);
                while ($fila = mysqli_fetch_assoc($result)) {
                    ?><tr><td><?=$fila['codigo']?></td><?php
                    ?><td><?=$fila['nombre']?></td><?php
                    ?><td><?=$fila['apellidos']?></td><?php
                    ?><td><?=$fila['tlfn']?></td><?php
                    ?><td><?=$fila['email']?></td><?php
                    ?><td><a href="gest_prof_2.php?id=<?=$fila['idprofesores']?>">Eliminar</a></td></tr><?php
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>